export default function TeamPage(){
  return (
    <main style={{padding:24}}>
      <h1>Schiera la formazione</h1>
      <p>Pagina demo: qui l'utente potrà scegliere i titolari (da completare).</p>
    </main>
  )
}
