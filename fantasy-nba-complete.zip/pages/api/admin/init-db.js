import prisma from '../../../lib/db'

export default async function handler(req, res) {
  const secret = req.query.secret || req.headers['x-init-secret']
  if (!process.env.DB_INIT_SECRET) return res.status(500).json({ error:'DB_INIT_SECRET not set on server' })
  if (!secret || secret !== process.env.DB_INIT_SECRET) return res.status(401).json({ error:'Unauthorized - secret mancante o errato' })

  const stmts = [
`CREATE TABLE IF NOT EXISTS "User" (
  id TEXT PRIMARY KEY,
  email TEXT UNIQUE NOT NULL,
  password TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'user',
  "createdAt" TIMESTAMPTZ NOT NULL DEFAULT now()
);`,
`CREATE TABLE IF NOT EXISTS "Player" (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  position TEXT,
  "nbaTeam" TEXT,
  "createdAt" TIMESTAMPTZ NOT NULL DEFAULT now()
);`,
`CREATE TABLE IF NOT EXISTS "League" (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  "adminId" TEXT NOT NULL,
  "createdAt" TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT fk_league_admin FOREIGN KEY ("adminId") REFERENCES "User"(id) ON DELETE CASCADE
);`,
`CREATE TABLE IF NOT EXISTS "Competition" (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  type TEXT NOT NULL,
  "leagueId" TEXT NOT NULL,
  "createdAt" TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT fk_competition_league FOREIGN KEY ("leagueId") REFERENCES "League"(id) ON DELETE CASCADE
);`,
`CREATE TABLE IF NOT EXISTS "Team" (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  "userId" TEXT NOT NULL,
  "competitionId" TEXT NOT NULL,
  "createdAt" TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT fk_team_user FOREIGN KEY ("userId") REFERENCES "User"(id) ON DELETE CASCADE,
  CONSTRAINT fk_team_comp FOREIGN KEY ("competitionId") REFERENCES "Competition"(id) ON DELETE CASCADE
);`,
`CREATE TABLE IF NOT EXISTS "Match" (
  id TEXT PRIMARY KEY,
  "competitionId" TEXT NOT NULL,
  day INTEGER NOT NULL,
  "teamAId" TEXT NOT NULL,
  "teamBId" TEXT NOT NULL,
  "scoreA" INTEGER,
  "scoreB" INTEGER,
  "createdAt" TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT fk_match_comp FOREIGN KEY ("competitionId") REFERENCES "Competition"(id) ON DELETE CASCADE,
  CONSTRAINT fk_match_teamA FOREIGN KEY ("teamAId") REFERENCES "Team"(id) ON DELETE CASCADE,
  CONSTRAINT fk_match_teamB FOREIGN KEY ("teamBId") REFERENCES "Team"(id) ON DELETE CASCADE
);`,
`CREATE TABLE IF NOT EXISTS "TeamPlayer" (
  id TEXT PRIMARY KEY,
  "teamId" TEXT NOT NULL,
  "playerId" TEXT NOT NULL,
  "isStarter" BOOLEAN NOT NULL DEFAULT false,
  "createdAt" TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT fk_tp_team FOREIGN KEY ("teamId") REFERENCES "Team"(id) ON DELETE CASCADE,
  CONSTRAINT fk_tp_player FOREIGN KEY ("playerId") REFERENCES "Player"(id) ON DELETE CASCADE
);`,
`CREATE TABLE IF NOT EXISTS "Result" (
  id TEXT PRIMARY KEY,
  "playerId" TEXT NOT NULL,
  "gameDay" INTEGER,
  points INTEGER NOT NULL DEFAULT 0,
  rebounds INTEGER NOT NULL DEFAULT 0,
  assists INTEGER NOT NULL DEFAULT 0,
  "createdAt" TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT fk_result_player FOREIGN KEY ("playerId") REFERENCES "Player"(id) ON DELETE CASCADE
);`
  ]

  try {
    for (const sql of stmts) {
      await prisma.$executeRawUnsafe(sql)
    }
    return res.status(200).json({ ok: true, message: 'Tabelle create (se non esistevano)' })
  } catch (e) {
    console.error('INIT-DB ERROR', e)
    return res.status(500).json({ error: String(e) })
  } finally {
    try { await prisma.$disconnect() } catch(e){}
  }
}
