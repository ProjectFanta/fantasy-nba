import prisma from '../../../lib/db'

export default async function handler(req, res){
  if (req.method !== 'POST') return res.status(405).json({ error:'Method not allowed' })
  try {
    const p1 = await prisma.player.upsert({
      where: { name: 'Giocatore Demo' },
      update: {},
      create: { id: 'p-' + Date.now(), name: 'Giocatore Demo', position: 'G', nbaTeam: 'NYK' }
    })
    await prisma.result.create({
      data: { id: 'r-' + Date.now(), playerId: p1.id, gameDay: 1, points: 25, rebounds: 5, assists: 7 }
    })
    return res.json({ message: 'Risultati di esempio inseriti.' })
  } catch (e) {
    console.error(e)
    return res.status(500).json({ error: String(e) })
  } finally {
    try{ await prisma.$disconnect() }catch(e){}
  }
}
