import Link from 'next/link'

export default function Home() {
  return (
    <main style={{padding:24, fontFamily:'system-ui'}}>
      <h1>Fantasy NBA — Starter</h1>
      <p>Benvenuto! Questo è lo starter kit.</p>
      <ul>
        <li><Link href='/admin'>Admin Dashboard</Link></li>
        <li><Link href='/team'>Schiera la formazione</Link></li>
      </ul>
    </main>
  )
}
