import { useState } from 'react'

export default function AdminPage(){
  const [message, setMessage] = useState('')
  async function uploadSample(){
    const res = await fetch('/api/admin/uploadResults', {method:'POST'})
    const j = await res.json()
    setMessage(j.message || j.error)
  }
  return (
    <main style={{padding:24}}>
      <h1>Admin dashboard</h1>
      <p>Qui l'admin caricherà i risultati manualmente.</p>
      <button onClick={uploadSample}>Simula caricamento risultati</button>
      <p>{message}</p>
    </main>
  )
}
