# Fantasy NBA — Starter (Cloud-only flow)

Questo pacchetto contiene un progetto Next.js + Prisma pronto per essere caricato su GitHub e deployato su Vercel, con database su Supabase.

**Obiettivo**: tu carichi lo zip su GitHub, crei il progetto Supabase (database), colleghi il repo a Vercel e incolli 3 variabili d'ambiente. Dopo il deploy esegui una singola URL per creare le tabelle. Poi rimuovi la route di inizializzazione per sicurezza.

## File principali
- `prisma/schema.prisma` — schema Prisma (Users, Leagues, Competitions, Teams, Players, Results, Matches)
- `pages/api/admin/init-db.js` — route temporanea per creare le tabelle (usare 1 volta)
- `pages/api/admin/uploadResults.js` — demo per inserire risultati di esempio
- `pages/api/teams.js` — demo API per leggere squadre
- semplici pagine: `/`, `/admin`, `/team`

## Guida MINIMA (passi rapidi)
1. Crea un nuovo repository su GitHub (es. `fantasy-nba`).
2. Carica il contenuto di questo zip (Upload files) e committa su `main`.
3. Crea progetto su Supabase → copia la **Connection string** (URI).
   - Se la password contiene `@` o altri caratteri speciali, URL-encodala (es. `@` -> `%40`).
   - Assicurati di usare `?schema=public` alla fine della stringa.
4. Su Vercel importa il repo GitHub:
   - Build Command: `npx prisma generate && npm run build`
   - Environment Variables (Production or All Environments):
     - `DATABASE_URL` = stringa connection (includi `?schema=public`)
     - `JWT_SECRET` = una stringa segreta (es. `fantasy_secret_...`)
     - `DB_INIT_SECRET` = una stringa segreta per inizializzare il DB (es. `init_fantasy_123`)
   - Deploy.
5. Dopo il deploy, apri nel browser:
   `https://TUO-PROGETTO.vercel.app/api/admin/init-db?secret=DB_INIT_SECRET_VALORE`
   - Dovrebbe restituire JSON con `ok: true`.
6. **Pulizia importantissima**:
   - Su GitHub cancella il file `pages/api/admin/init-db.js` (Delete file -> commit).
   - Su Vercel elimina la variabile `DB_INIT_SECRET` e fai Redeploy.

## Test rapidi
- Vai su `/admin` e premi "Simula caricamento risultati" per inserire dati di esempio.
- Vai su `/api/teams` per vedere le squadre (mostra un array se esistono).

Se preferisci, posso guidarti passo-passo mentre fai ogni click — dimmi quando vuoi iniziare.
